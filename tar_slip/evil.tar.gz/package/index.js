// This code runs when require()'d
console.log("[*] evil-pkg loaded");
module.exports = { loaded: true, timestamp: Date.now() };
